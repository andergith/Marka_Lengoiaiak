function aldatuTestua() {
    let tit = document.getElementById('izenburua');
    tit.childNodes[0].nodeValue = 'Orain ikus dezakegu titulu berria';
}
