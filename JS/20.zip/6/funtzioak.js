function aldatuKolorea() {
    let erakusle = document.getElementById('parrafo1');
    let guraso = erakusle.parentNode;
    guraso.style.backgroundColor = '#fff000';
}
