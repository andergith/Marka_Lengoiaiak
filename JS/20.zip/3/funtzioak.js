function aldatukolorea() {
    let tit = document.getElementById('H1')
    tit.style.color = '#ff0000'
}

function aldatutamaina() {
    let tit = document.getElementById('H1')
    tit.style.fontSize = '60px'
}

